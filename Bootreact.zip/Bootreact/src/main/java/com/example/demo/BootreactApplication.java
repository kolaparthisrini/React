package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.pojo.Employee;
import com.example.demo.repository.EmployeeRepository;

@SpringBootApplication
public class BootreactApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(BootreactApplication.class, args);
	}
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public void run(String... args) throws Exception {

		Employee employee1 = new Employee();
		employee1.setEmail("vasu34k@gmail.co");
		employee1.setFirstName("Srinivas");
		employee1.setLastName("srinivas");
				
				
		Employee employee2 = new Employee();
		employee2.setEmail("kyzen@gmail.co");
		employee2.setFirstName("MArley");
		employee2.setLastName("bob");

		employeeRepository.save(employee1);
		employeeRepository.save(employee2);
	
	}

}
